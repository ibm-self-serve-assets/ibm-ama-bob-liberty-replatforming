#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2026
# ---------------------------------------------

# Determine script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

source ./logging.sh
source ./findHost.sh
source ./oauth_utils.sh

# Configuration status tracking
CONFIG_SUCCESS=false
CONFIG_ERRORS=0
CONFIG_WARNINGS=0

# Constants
STATUS_INFO="[INFO]"
BOLD_CYAN="\e[1;36m"
DEFAULT_OAUTH_CONFIG="./.oauth_config"
BACKUP_TIMESTAMP_FORMAT="+%Y%m%d_%H%M%S"
PLACEHOLDER_VALUES=("sample" "test" "placeholder")

# Endpoint mappings: discovery_key:var_base:display_name
ENDPOINT_MAPPINGS=(
    "authorization_endpoint:TA_AUTH_IDENTITY_REQUEST_ENDPOINT:Authorization"
    "token_endpoint:TA_AUTH_TOKEN_REQUEST_ENDPOINT:Token"
    "userinfo_endpoint:TA_AUTH_TOKEN_VERIFICATION_ENDPOINT:Userinfo"
    "revocation_endpoint:TA_AUTH_TOKEN_REVOCATION_ENDPOINT:Revocation"
    "end_session_endpoint:TA_AUTH_END_SESSION_ENDPOINT:End session"
)

#
# Function: print_oauth_section_header
# Description: Prints a lightweight OAuth section header
# Parameters:
#   $1 - Section title
#
print_oauth_section_header() {
    local title=$1
    to_terminal "${BOLD_CYAN}=== ${title} ===${RESET}"
}

#
# Function: should_configure_oauth
# Description: Checks if OAuth configuration should run based on auth enabled flag
# Returns: 0 if should proceed, 1 if should skip
#
should_configure_oauth() {
    local auth_enabled="${APPMOD_AUTH_ENABLED:-false}"
    auth_enabled=$(printf '%s' "$auth_enabled" | tr '[:upper:]' '[:lower:]')
    
    if [[ "$auth_enabled" != "true" ]]; then
        to_terminal "Authentication is disabled (APPMOD_AUTH_ENABLED=${auth_enabled}) - skipping OAuth configuration"
        to_terminal ""
        return 1
    fi
    
    return 0
}

#
# Function: is_placeholder_value
# Description: Checks if a value is a placeholder/sample value
# Parameters:
#   $1 - Value to check
# Returns: 0 if placeholder, 1 if not
#
is_placeholder_value() {
    local value=$1
    for placeholder in "${PLACEHOLDER_VALUES[@]}"; do
        if [[ "$value" == "$placeholder" ]]; then
            return 0
        fi
    done
    return 1
}

#
# Function: is_endpoint_manually_configured
# Description: Checks if an endpoint variable is manually configured in config file
# Parameters:
#   $1 - Variable name to check
# Returns: 0 if manually configured, 1 if not
# Note: OAUTH_CONFIG_FILE is exported by enableSecurity.sh's importSecurityEnv() function,
#       which determines whether to use .oauth_config or .oauth_config.dev
#
is_endpoint_manually_configured() {
    local var_name=$1
    local config_file="${OAUTH_CONFIG_FILE:-$DEFAULT_OAUTH_CONFIG}"
    
    [[ ! -f "$config_file" ]] && return 1
    
    local var_value=$(grep "^[[:space:]]*${var_name}=" "$config_file" 2>/dev/null | head -n1 | cut -d'=' -f2- | tr -d ' ')
    
    if [[ -n "$var_value" ]] && ! is_placeholder_value "$var_value"; then
        return 0
    fi
    
    return 1
}

#
# Function: all_endpoints_configured
# Description: Checks whether all OAuth endpoints are already manually configured
# Returns: 0 if all are manually configured, 1 otherwise
#
all_endpoints_configured() {
    for mapping in "${ENDPOINT_MAPPINGS[@]}"; do
        local rest="${mapping#*:}"
        local var_base="${rest%%:*}"

        if ! is_endpoint_manually_configured "$var_base"; then
            return 1
        fi
    done

    return 0
}

#
# Function: split_endpoint_url
# Description: Splits a full URL into base and path components
# Parameters:
#   $1 - Full URL
# Output: Prints "base_url path" separated by space
#
split_endpoint_url() {
    local full_url=$1
    local base=$(echo "$full_url" | grep -o '^https\?://[^/]*')
    local path="${full_url#$base}"
    [[ -z "$path" ]] && path="/"
    echo "$base $path"
}

#
# Function: update_config_variable
# Description: Updates or adds a variable in the config file
# Parameters:
#   $1 - Variable name
#   $2 - Variable value
#   $3 - Config file path
#
update_config_variable() {
    local var_name=$1
    local var_value=$2
    local config_file=$3
    
    # Check if the variable already exists in the config file (with optional leading whitespace)
    if grep -q "^[[:space:]]*${var_name}=" "$config_file"; then
        # Variable exists: update its value using sed
        # -i.tmp creates a backup, then we remove it after successful update
        # The regex matches the line and replaces the entire line with var_name=var_value
        sed -i.tmp "s|^[[:space:]]*${var_name}=.*|${var_name}=${var_value}|" "$config_file"
        rm -f "${config_file}.tmp"
    else
        # Variable doesn't exist: append it to the file
        append_config_line_safely "$config_file" "${var_name}=${var_value}"
    fi
}

#
# Function: process_endpoint
# Description: Processes a single OAuth endpoint - auto-populates if needed and validates
# Parameters:
#   $1 - Discovery JSON key
#   $2 - Variable base name
#   $3 - Display name
#   $4 - Discovered URL
# Returns: 0 if processed, 1 if skipped
# Note: Appends to global config_updates array
#       OAuth endpoints are split into base URL and path for flexibility:
#       - var_base (e.g., TA_AUTH_TOKEN_REQUEST_ENDPOINT) = base URL (e.g., https://host:port)
#       - var_base_PATH (e.g., TA_AUTH_TOKEN_REQUEST_ENDPOINT_PATH) = path (e.g., /realms/dev/protocol/openid-connect/token)
#       This allows the application to construct full URLs dynamically and handle different deployment scenarios
#
process_endpoint() {
    local json_key=$1
    local var_base=$2
    local display_name=$3
    local discovered_url=$4
    
    if [[ -z "$discovered_url" ]]; then
        return 1
    fi
    
    if is_endpoint_manually_configured "$var_base"; then
        log "\t   ${STATUS_INFO} $display_name endpoint: Using manual configuration"
        return 1
    fi

    local base path
    read base path <<< "$(split_endpoint_url "$discovered_url")"
    # Store base URL and path separately for flexibility in different deployment scenarios
    config_updates+=("${var_base}=$base")
    config_updates+=("${var_base}_PATH=$path")
    log "\t   ${STATUS_OK} $display_name endpoint: $discovered_url"
    return 0
}

#
# Function: auto_populate_endpoints
# Description: Auto-populates OAuth endpoints from OIDC discovery document
# Parameters:
#   $1 - Discovery JSON
# Returns: Number of endpoints populated
#
auto_populate_endpoints() {
    local discovery_json=$1
    local endpoints_populated=0
    declare -a config_updates=()
    
    log "\t   Populating OAuth endpoints:"
    
    # Process each endpoint
    for mapping in "${ENDPOINT_MAPPINGS[@]}"; do
        local json_key="${mapping%%:*}"
        local rest="${mapping#*:}"
        local var_base="${rest%%:*}"
        local display_name="${rest#*:}"
        local discovered_url=$(extract_json_value "$discovery_json" "$json_key")
        
        if process_endpoint "$json_key" "$var_base" "$display_name" "$discovered_url"; then
            ((endpoints_populated++))
        fi
    done
    
    local config_file="${OAUTH_CONFIG_FILE:-$DEFAULT_OAUTH_CONFIG}"

    # Apply endpoint updates only when discovery filled in missing endpoint values.
    if [[ ${#config_updates[@]} -eq 0 ]]; then
        to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} All endpoints already manually configured - skipping auto discovery"
        log "${STATUS_INFO_SYMBOL} All endpoints already manually configured - skipping auto discovery"
        to_terminal ""
        return 0
    fi

    local backup_file="${config_file}.backup.$(date $BACKUP_TIMESTAMP_FORMAT)"
    
    if [[ -f "$config_file" ]]; then
        cp "$config_file" "$backup_file"
        log "\tCreated backup: $backup_file"
    fi
    
    # Ensure OAuth section header exists before writing OAuth variables
    ensure_oauth_section_header "$config_file"
    
    # Ensure the default OIDC scope is present (write after header)
    update_config_variable "TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE" "openid" "$config_file"
    
    for update in "${config_updates[@]}"; do
        local var_name="${update%%=*}"
        local var_value="${update#*=}"
        update_config_variable "$var_name" "$var_value" "$config_file"
    done
    
    to_terminal "${GREEN}${STATUS_OK_SYMBOL}${RESET} Updated ${config_file#./} with auto-populated endpoints"
    to_terminal ""
    
    return $endpoints_populated
}

#
# Function: validate_required_variable
# Description: Validates that a required variable is set and not a placeholder
# Parameters:
#   $1 - Variable name
#   $2 - Variable value
#   $3 - Display name
# Returns: 0 if valid, 1 if invalid
#
validate_required_variable() {
    local var_name=$1
    local var_value=$2
    local display_name=$3
    
    if [[ -z "$var_value" ]]; then
        log "\tError: $display_name is not set (variable: $var_name)"
        log ""
        log "\t         Please set $var_name in .oauth_config"
        ((CONFIG_ERRORS++))
        return 1
    fi
    
    if is_placeholder_value "$var_value"; then
        terminal_error "$display_name contains sample/placeholder value: $var_value"
        log ""
        log "\t         Please update with actual value"
        ((CONFIG_ERRORS++))
        return 1
    fi
    
    return 0
}

#
# Function: validate_endpoint_match
# Description: Validates configured endpoint matches discovered endpoint
# Parameters:
#   $1 - Endpoint name
#   $2 - Discovered URL
#   $3 - Configured URL
# Returns: 0 if matches, 1 if mismatch
#
validate_endpoint_match() {
    local name=$1
    local discovered=$2
    local configured=$3
    
    [[ -z "$discovered" ]] && return 0
    
    if [[ "$discovered" != "$configured" ]]; then
        log "\tError: Configured $name does not match discovered endpoint"
        log "\t         Configured: $configured"
        log "\t         Discovered: $discovered"
        log "\t         OAuth flow will fail - you MUST use the discovered endpoint"
        log ""
        ((CONFIG_ERRORS++))
        return 1
    fi
    
    return 0
}

#
# Function: validate_callback_uri
# Description: Validates callback URI format
# Parameters:
#   $1 - Callback URI
# Returns: 0 if valid, 1 if invalid
#
validate_callback_uri() {
    local callback_uri=$1
    
    if [[ ! "$callback_uri" =~ ^https?:// ]]; then
        log "\tError: Callback URI has invalid format: $callback_uri"
        log "\t         Must start with http:// or https://"
        log ""
        ((CONFIG_ERRORS++))
        return 1
    fi
    
    if [[ ! "$callback_uri" =~ /auth/callback$ ]]; then
        terminal_warn "Callback URI should end with /auth/callback"
        log "\t         Current: $callback_uri"
        log "\t         Expected: http(s)://your-host:port/auth/callback"
        log ""
        ((CONFIG_WARNINGS++))
    fi
    
    return 0
}

#
# Function: auto_populate_oauth
# Description: Auto-populates OAuth endpoints from OIDC discovery document
# Returns: Discovery JSON (stored in OAUTH_DISCOVERY_JSON variable for validation)
#
auto_populate_oauth() {
    if ! should_configure_oauth; then
        return 0
    fi

    print_oauth_section_header "OAuth Auto Discovery - START"
    
    # Check TA_AUTH_OIDC_ISSUER and attempt auto-population
    local endpoints_populated=0
    OAUTH_DISCOVERY_JSON=""
    
    if [[ -z "${TA_AUTH_OIDC_ISSUER:-}" ]]; then
        terminal_warn "TA_AUTH_OIDC_ISSUER is not set - OIDC Auto Discovery will be skipped"
        log "\t         This is acceptable if your OIDC provider doesn't support discovery."
        log "\t         Ensure all OAuth endpoint variables are correctly configured."
        print_oauth_section_header "OAuth Auto Discovery - END"
        to_terminal ""
        return 0
    fi

    if all_endpoints_configured; then
        to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} All endpoints already manually configured - skipping auto discovery"
        log "${STATUS_INFO_SYMBOL} All endpoints already manually configured - skipping auto discovery"
        print_oauth_section_header "OAuth Auto Discovery - END"
        to_terminal ""
        return 0
    fi

    to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} OIDC Issuer configured: $TA_AUTH_OIDC_ISSUER"
    to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} Fetching OIDC discovery document..."

    OAUTH_DISCOVERY_JSON=$(fetch_oidc_discovery "$TA_AUTH_OIDC_ISSUER")

    if [[ -z "$OAUTH_DISCOVERY_JSON" ]]; then
        terminal_warn "Could not fetch OIDC discovery document from: $TA_AUTH_OIDC_ISSUER"
        log "\t         Auto-population skipped"
        log "\t         Validation will continue using manual endpoint configuration"
        log ""
        print_oauth_section_header "OAuth Auto Discovery - END"
        to_terminal ""
        return 0
    fi

    to_terminal "${GREEN}${STATUS_OK_SYMBOL}${RESET} Discovery document fetched successfully"

    auto_populate_endpoints "$OAUTH_DISCOVERY_JSON"
    endpoints_populated=$?

    if [[ $endpoints_populated -gt 0 ]]; then
        to_terminal "${GREEN}${STATUS_OK_SYMBOL}${RESET} Auto-populated $endpoints_populated OAuth endpoint(s)"
    fi
    
    print_oauth_section_header "OAuth Auto Discovery - END"
    to_terminal ""
    
    return 0
}

#
# Function: _prompt_oidc_cred
# Description: Prompts the user interactively for a single OIDC credential.
#              Input is read in silent mode so it never appears in the terminal or
#              shell history. The value is stored in the named output variable.
# Parameters:
#   $1 - Display label (e.g. "Client ID")
#   $2 - Output variable name
#
_prompt_oidc_cred() {
    local label=$1
    local out_var=$2
    local value=""
    while [[ -z "$value" ]]; do
        # printf directly to fd 4 (terminal): no newline so cursor stays inline,
        # and the value must NOT be logged — use printf, not to_terminal.
        printf "\t${BOLD_CYAN}Enter OIDC %s:${RESET} " "$label" >&4
        IFS= read -rs value <&4
        printf "\n" >&4
        if [[ -z "$value" ]]; then
            to_terminal "${YELLOW}${STATUS_WARN_SYMBOL}${RESET} $label cannot be empty. Please try again."
        fi
    done
    printf -v "$out_var" '%s' "$value"
}

#
# Function: create_oidc_secrets
# Description: Ensures Podman secrets for the OIDC client ID and secret exist.
#              If both secrets already exist, or both env vars are set, they are
#              used directly. Otherwise the user is prompted for both at once.
#
create_oidc_secrets() {
    source ./secretHelper.sh

    local id_value="${TA_AUTH_OIDC_CLIENT_ID:-}"
    local secret_value="${TA_AUTH_OIDC_CLIENT_SECRET:-}"
    local id_exists secret_exists

    [[ "$(podman secret inspect ta_auth_oidc_client_id     2>/dev/null)" != '[]' ]] && id_exists=true
    [[ "$(podman secret inspect ta_auth_oidc_client_secret 2>/dev/null)" != '[]' ]] && secret_exists=true

    # Case 1: Both Podman secrets already exist — nothing to do
    if [[ "$id_exists" == "true" && "$secret_exists" == "true" ]]; then
        log "[INFO] OIDC secrets already exist — reusing"
        return 0
    fi

    # Case 2: Both env vars are set (e.g. from .security_config)
    if [[ -n "$id_value" && -n "$secret_value" ]]; then
        log "[INFO] Creating OIDC secrets from env vars"
        createSecret "ta_auth_oidc_client_id"     "dummy" "$id_value"
        createSecret "ta_auth_oidc_client_secret" "dummy" "$secret_value"
        return 0
    fi

    # Case 3: Prompt for both at once
    to_terminal ""
    to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} OIDC credentials not found. Enter them now to continue installation."
    to_terminal "   ${YELLOW}(input is hidden and will be stored as Podman secrets)${RESET}"

    local client_id="" client_secret=""
    _prompt_oidc_cred "Client ID"     client_id
    _prompt_oidc_cred "Client Secret" client_secret

    log "[INFO] Creating OIDC secrets"
    printf '%s' "$client_id"     | podman secret create ta_auth_oidc_client_id -
    printf '%s' "$client_secret" | podman secret create ta_auth_oidc_client_secret -
    unset client_id client_secret
}

#
# Function: validate_client_configs
# Description: Validates OAuth client ID, secret, callback URI, and scope
# Returns: 0 if all valid, 1 if any invalid
#
validate_client_configs() {
    local all_valid=true

    validate_required_variable "TA_AUTH_OIDC_CALLBACK_URI" "${TA_AUTH_OIDC_CALLBACK_URI:-}" "OAuth Callback URI"                             || all_valid=false
    validate_required_variable "TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE" "${TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE:-}" "Authorization Scope" || all_valid=false
    if [[ -n "${TA_AUTH_OIDC_CALLBACK_URI:-}" ]]; then
        validate_callback_uri "$TA_AUTH_OIDC_CALLBACK_URI" || all_valid=false
    fi

    [[ "$all_valid" == "true" ]] && return 0 || return 1
}

#
# Function: validate_all_endpoints
# Description: Validates all OAuth endpoint variables (base URL and path)
# Returns: 0 if all valid, 1 if any invalid
#
validate_all_endpoints() {
    local all_valid=true
    
    for mapping in "${ENDPOINT_MAPPINGS[@]}"; do
        local json_key="${mapping%%:*}"
        local rest="${mapping#*:}"
        local var_base="${rest%%:*}"
        local display_name="${rest#*:}"
        
        # Use eval to get variable values (bash 3.2 compatible)
        local endpoint_value=$(eval echo "\${${var_base}:-}")
        local path_value=$(eval echo "\${${var_base}_PATH:-}")
        
        validate_required_variable "${var_base}" "$endpoint_value" "$display_name Endpoint" || all_valid=false
        validate_required_variable "${var_base}_PATH" "$path_value" "$display_name Path" || all_valid=false
    done
    
    [[ "$all_valid" == "true" ]] && return 0 || return 1
}

#
# Function: validate_against_discovery
# Description: Validates configured endpoints match OIDC discovery document
# Returns: 0 if all match or discovery unavailable, 1 if mismatches found
#
validate_against_discovery() {
    # Skip if no issuer configured
    [[ -z "${TA_AUTH_OIDC_ISSUER:-}" ]] && return 0
    
    # Fetch discovery document if not already available
    if [[ -z "${OAUTH_DISCOVERY_JSON:-}" ]]; then
        to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} Fetching OIDC discovery document for validation..."
        log "${STATUS_INFO_SYMBOL} Fetching OIDC discovery document for validation..."
        OAUTH_DISCOVERY_JSON=$(fetch_oidc_discovery "$TA_AUTH_OIDC_ISSUER")
    fi

    # If discovery document unavailable, warn but don't fail
    if [[ -z "${OAUTH_DISCOVERY_JSON:-}" ]]; then
        terminal_warn "Could not validate configured endpoints against OIDC discovery from: $TA_AUTH_OIDC_ISSUER. Make sure manually configured endpoints are correct"
        log "\t         Endpoint comparison against OIDC discovery was skipped because the discovery document could not be retrieved from: $TA_AUTH_OIDC_ISSUER"
        log ""
        ((CONFIG_WARNINGS++))
        return 0
    fi

    # Validate each endpoint against discovery
    to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} Validating endpoints against OIDC discovery..."
    log "${STATUS_INFO_SYMBOL} Validating endpoints against OIDC discovery..."
    
    local has_mismatches=false
    for mapping in "${ENDPOINT_MAPPINGS[@]}"; do
        local json_key="${mapping%%:*}"
        local rest="${mapping#*:}"
        local var_base="${rest%%:*}"
        local display_name="${rest#*:}"
        local discovered_url=$(extract_json_value "$OAUTH_DISCOVERY_JSON" "$json_key")
        
        # Use eval to get variable values (bash 3.2 compatible)
        local endpoint_value=$(eval echo "\${${var_base}:-}")
        local path_value=$(eval echo "\${${var_base}_PATH:-}")
        local configured_url="${endpoint_value}${path_value}"
        
        if ! validate_endpoint_match "$display_name endpoint" "$discovered_url" "$configured_url"; then
            has_mismatches=true
        fi
    done
    
    if [[ "$has_mismatches" == "false" ]]; then
        to_terminal "${GREEN}${STATUS_OK_SYMBOL}${RESET} All configured OAuth endpoints match OIDC discovery document"
        log "${STATUS_OK_SYMBOL} All configured OAuth endpoints match OIDC discovery document"
        return 0
    fi
    
    return 1
}

#
# Function: print_validation_summary
# Description: Prints validation summary based on error and warning counts
# Returns: 0 if validation successful, 1 if failed
#
print_validation_summary() {
    if [[ $CONFIG_ERRORS -eq 0 ]] && [[ $CONFIG_WARNINGS -eq 0 ]]; then
        to_terminal "${GREEN}${STATUS_OK_SYMBOL}${RESET} OAuth configuration complete and valid"
        CONFIG_SUCCESS=true
    elif [[ $CONFIG_ERRORS -eq 0 ]]; then
        to_terminal "${YELLOW}${STATUS_WARN_SYMBOL}${RESET} OAuth configuration complete with $CONFIG_WARNINGS warning(s)"
        CONFIG_SUCCESS=true
    else
        to_terminal "${RED}${STATUS_ERROR_SYMBOL}${RESET} OAuth configuration failed with $CONFIG_ERRORS error(s) and $CONFIG_WARNINGS warning(s)"
        to_terminal "   ${RED}Check logs/output.$(date +'%Y-%m-%d').log for detailed errors${RESET}"
        to_terminal "   ${RED}Please fix the errors and try again${RESET}"
        CONFIG_SUCCESS=false
    fi
    
    [[ "$CONFIG_SUCCESS" == "true" ]] && return 0 || return 1
}

#
# Function: validate_oauth
# Description: Validates OAuth configuration by orchestrating validation steps
# Returns: 0 on success, 1 on failure
#
validate_oauth() {
    if ! should_configure_oauth; then
        return 0
    fi
    
    print_oauth_section_header "OAuth Validation - START"

    # Reset counters
    CONFIG_ERRORS=0
    CONFIG_WARNINGS=0

    # Step 1: Validate client configs (callback URI, scope)
    validate_client_configs

    # Step 2: Validate all endpoint variables (base URL and path for each endpoint)
    validate_all_endpoints

    # Step 3: Validate endpoints against OIDC discovery document (if issuer configured)
    validate_against_discovery

    # Step 4: Print validation summary
    print_validation_summary
    local result=$?
    
    print_oauth_section_header "OAuth Validation - END"
	to_terminal ""
    
    return $result
}

#
# Function: configure_oauth
# Description: Main function - auto-populates and validates OAuth configuration
# Returns: 0 on success, 1 on failure
#
configure_oauth() {
    # Run auto-population
    auto_populate_oauth
    
    # Run validation
    validate_oauth
}

# Export functions
export -f auto_populate_oauth
export -f validate_oauth
export -f configure_oauth

# Main execution
main() {
    ensure_log_dir
    configure_oauth
    return $?
}

# Run main function if script is executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

# Made with Bob
