
echo OFF
set /p portnumber=<config.txt

SET "port=%portnumber:~5%"

echo Creating the TA Volumes
podman volume create tadb
podman volume create tagraph
echo Creating the Pod
podman pod create -n ta_pod -p %port%:3000 -p 2220:9080
echo Downloading and Configuring the Application Modernization Accelerator Containers
podman run  -d --pod ta_pod --name tadb --env-file env_couch.list -v "tadb:/opt/couchdb/data" icr.io/appcafe/transformation-advisor-db:5.0.1 > null 
podman run  -d --pod ta_pod --name tagraph --env-file  env_graph.list -v "tagraph:/data" icr.io/appcafe/transformation-advisor-neo4j:5.0.1 > null 
podman run -d --pod ta_pod --name taserver  --env-file env_server.list icr.io/appcafe/transformation-advisor-server:5.0.1 > null 
podman run -d --pod ta_pod --name taui  --env-file env_ui.list icr.io/appcafe/transformation-advisor-ui:5.0.1 > null 

timeout 10 > null
echo:
echo:
echo Application Modernization Accelerator is available at: http://localhost:%port%
echo:
