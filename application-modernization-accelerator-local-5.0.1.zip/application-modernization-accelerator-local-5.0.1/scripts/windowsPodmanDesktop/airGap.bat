echo off


ECHO Have you already saved the Application Modernization Accelerator images to a tarball (y/n)?

set /p air=Type option:
if "%air%"=="n" goto noAir
if "%air%"=="y" goto Air

:noAir
ECHO:
ECHO How to create the Application Modernization Accelerator image file.
ECHO -------------------------------------------------------------------------------------------------
ECHO On a system that has podman installed and has internet connectivity, pull the images.
ECHO Then, save the images to a gzip'd tar ball.
ECHO:
ECHO podman pull icr.io/appcafe/transformation-advisor-db:5.0.1
ECHO podman pull icr.io/appcafe/transformation-advisor-ui:5.0.1
ECHO podman pull icr.io/appcafe/transformation-advisor-server:5.0.1
ECHO podman pull icr.io/appcafe/transformation-advisor-neo4j:5.0.1
ECHO:
ECHO:
ECHO podman save -m icr.io/appcafe/transformation-advisor-db:5.0.1 icr.io/appcafe/transformation-advisor-ui:5.0.1 icr.io/appcafe/transformation-advisor-server:5.0.1 icr.io/appcafe/transformation-advisor-neo4j:5.0.1 -o  ama-images.tar.gz
ECHO:
ECHO Transfer the file to the target server and run the launch script.
ECHO Choose the option to work in an air gapped environment and you will be prompted to enter the location of the tarball containing the images.
ECHO:
goto begin

:Air
ECHO:
ECHO Enter filename location (eg, C:\ama-images.tar.gz)
ECHO:
set /p "PathInput=Enter Path: "
ECHO:
ECHO %PathInput% >%TMP%\var_c

if not exist %PathInput% (
    echo %PathInput% does not exist
    ECHO:
    EXIT /B
) else (
    goto airInstall
)
:airInstall
airInstall.bat
goto begin

ECHO %path%


echo:
