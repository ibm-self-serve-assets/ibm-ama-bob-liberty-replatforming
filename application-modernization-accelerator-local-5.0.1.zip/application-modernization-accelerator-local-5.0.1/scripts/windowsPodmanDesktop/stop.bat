echo off
podman stop tadb
podman stop tagraph
podman stop taserver
podman stop taui

echo:
