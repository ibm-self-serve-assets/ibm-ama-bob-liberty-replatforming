echo off
echo Get podman version

set YYYYMMDD=%date:~6,4%-%date:~3,2%-%date:~0,2%-%time:~0,2%-%time:~3,2%-%time:~6,2%


podman version >> debugLog_%YYYYMMDD%.txt

echo: >> debugLog_%YYYYMMDD%.txt
echo: >> debugLog_%YYYYMMDD%.txt

echo Get image information >> debugLog_%YYYYMMDD%.txt
echo --------------------- >> debugLog_%YYYYMMDD%.txt
podman images >> debugLog_%YYYYMMDD%.txt

echo: >> debugLog_%YYYYMMDD%.txt
echo: >> debugLog_%YYYYMMDD%.txt

echo Running containers >> debugLog_%YYYYMMDD%.txt
echo --------------------- >> debugLog_%YYYYMMDD%.txt
podman ps >> debugLog_%YYYYMMDD%.txt

echo: >> debugLog_%YYYYMMDD%.txt
echo: >> debugLog_%YYYYMMDD%.txt

echo Get Volumes >> debugLog_%YYYYMMDD%.txt
echo --------------------- >> debugLog_%YYYYMMDD%.txt
podman volume ls >> debugLog_%YYYYMMDD%.txt

echo: >> debugLog_%YYYYMMDD%.txt
echo: >> debugLog_%YYYYMMDD%.txt
