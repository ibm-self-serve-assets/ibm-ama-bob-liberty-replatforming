echo off
echo Stopping Application Modernization Accelerator
podman start tadb
podman start tagraph
podman start taserver
podman start taui

echo:
