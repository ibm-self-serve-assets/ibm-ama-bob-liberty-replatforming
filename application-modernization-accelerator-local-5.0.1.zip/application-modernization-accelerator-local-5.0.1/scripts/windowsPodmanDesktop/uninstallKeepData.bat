echo off
echo Stopping Application Modernization Accelerator
podman stop tadb
podman stop tagraph
podman stop taserver
podman stop taui

echo Removing Application Modernization Accelerator containers
podman rm -f tadb tagraph taserver taui

echo Removing the Application Modernization Accelerator Images

podman rmi -f icr.io/appcafe/transformation-advisor-ui:5.0.1
podman rmi -f icr.io/appcafe/transformation-advisor-server:5.0.1
podman rmi -f icr.io/appcafe/transformation-advisor-db:5.0.1
podman rmi -f icr.io/appcafe/transformation-advisor-neo4j:5.0.1

echo Remove Application Modernization Accelerator pod 

podman pod rm -f ta_pod
echo:
