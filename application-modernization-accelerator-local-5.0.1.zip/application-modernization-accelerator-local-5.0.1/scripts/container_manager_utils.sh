#!/bin/bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2025
# ---------------------------------------------

# File to store container manager preference
CONTAINER_MANAGER_PREFERENCE_FILE=".container_manager_preference"

required_images=("transformation-advisor-server" "transformation-advisor-ui" "transformation-advisor-db" "transformation-advisor-neo4j")

# Function to get the saved container manager preference
# Returns: "docker", "podman", or empty string if no preference saved
get_container_manager_preference() {
    if [[ -f "$CONTAINER_MANAGER_PREFERENCE_FILE" ]]; then
        cat "$CONTAINER_MANAGER_PREFERENCE_FILE"
    else
        echo ""
    fi
}

# Function to save container manager preference
# Parameters:
#   $1 - Container manager choice ("docker" or "podman")
save_container_manager_preference() {
    local choice="$1"
    echo "$choice" > "$CONTAINER_MANAGER_PREFERENCE_FILE"
    log "Saved container manager preference: $choice"
}

# Function to validate if the preferred container manager is installed
# Parameters:
#   $1 - Container manager preference ("docker" or "podman")
# Returns: 0 if installed, 1 if not installed
validate_container_manager_preference() {
    local preference="$1"
    
    if [[ "$preference" == "docker" ]]; then
        is_docker_installed
        return $?
    elif [[ "$preference" == "podman" ]]; then
        is_podman_installed
        return $?
    else
        return 1
    fi
}

# Function to prompt user to choose container manager
# Returns: User's choice ("docker" or "podman")
prompt_container_manager_choice() {
    to_terminal "Both Docker and Podman are installed on this system."
    to_terminal "Please select which container manager you would like to use:"
    
    prompt_and_read "\n\t1) Podman\n\t2) Docker\n\n\tEnter your choice (1 or 2)" CHOICE
    basic_input_validation "$CHOICE" 1 2

    case $CHOICE in
        1)
            echo "podman"
            ;;
        2)
            echo "docker"
            ;;
    esac
}

# Function to handle container manager selection when both are installed
# This function checks for saved preference, validates it, or prompts for new choice
handle_container_manager_selection() {
    local preference=$(get_container_manager_preference)
    
    # If preference exists, validate it
    if [[ -n "$preference" ]]; then
        log "Found saved container manager preference: $preference"
        
        if validate_container_manager_preference "$preference"; then
            log "Validated preference: $preference is installed"
            to_terminal "Using saved container manager preference: $preference"
            return 0
        else
            # Preference saved but that manager is no longer installed
            to_terminal "Your saved preference ($preference) is no longer installed."
            to_terminal "Please choose an available container manager."
            rm -f "$CONTAINER_MANAGER_PREFERENCE_FILE"
        fi
    fi
    
    # No valid preference, prompt user to choose
    local choice=$(prompt_container_manager_choice)
    save_container_manager_preference "$choice"
    
    to_terminal "\t%s\n" "Container manager preference saved: $choice"
    to_terminal "This preference will be used for future launches."
    to_terminal "To change your preference, delete the file: $CONTAINER_MANAGER_PREFERENCE_FILE"
    
    return 0
}


podman_image_trust_is_set() {
    # Check if image trust for 'icr.io' is set
    # This is only run if running as rootless
    # returns 0 if icr.io is found
    # returns 1 if not found
    podman image trust show | grep -q "icr.io"
    return $?
}

podman_set_trust(){
    if ! podman_image_trust_is_set; then
        podman image trust set -t accept icr.io
    fi
}


## docker can be docker or podman - depends on alias
is_cm_running(){
	## Use exit code of cm info so we don't have to rely on string match
	docker info > /dev/null 2>&1;
	exit_code=$?
	if [[  $exit_code -ne 0 ]]; then
		to_terminal "Docker installed but not running. Please start docker and re-run the script."
		exit
	fi
}

ensure_required_images_exist() {
	local images=("$@")
	local total=${#images[@]}
	local count=0

	for image in "${images[@]}"; do
		if docker images --format '{{.Repository}}' | grep -qE "${image}"; then
			((count++))
		fi
	done

	if [[ $count -eq $total ]]; then
		echo "all-present"
	elif [[ $count -gt 0 ]]; then
		echo "some-present"
	else
		echo "none-present"
	fi
}

set_image_status() {
	image_status=$(ensure_required_images_exist "${required_images[@]}")
}