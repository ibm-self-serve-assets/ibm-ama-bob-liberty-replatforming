
#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

source ./.security_config
source ./.oauth_config
source ./localTempPodman.sh
source ./logging.sh

source ./installHelper.sh
source ./checkPodsRunning.sh
source ./findHost.sh
source ./architecture_check.sh

# Reset only TA_PUBLIC_ACCESSIBLE_UI_URL from .env_orig to ensure fresh host IP detection
if [ -f "./.env_orig" ]; then
	log "Resetting TA_PUBLIC_ACCESSIBLE_UI_URL from .env_orig for fresh host IP detection"
	ta_ui_url_template=$(grep "^TA_PUBLIC_ACCESSIBLE_UI_URL=" ./.env_orig | cut -d'=' -f2-)
	if uname -s | grep 'Darwin' >/dev/null; then
		# macOS
		sed -i '' "s|^TA_PUBLIC_ACCESSIBLE_UI_URL=.*|TA_PUBLIC_ACCESSIBLE_UI_URL=${ta_ui_url_template}|g" ./.env
	else
		# Linux
		sed -i "s|^TA_PUBLIC_ACCESSIBLE_UI_URL=.*|TA_PUBLIC_ACCESSIBLE_UI_URL=${ta_ui_url_template}|g" ./.env
	fi
fi

# Verify image architecture compatibility before starting containers
verify_images_architecture
if [[ $? -ne 0 ]]; then
	log "ERROR: Image architecture verification failed!"
	log "Please ensure images are compatible with your system architecture."
	log "Installation cannot proceed with incompatible images."
	exit 1
fi

replaceHost
sleep 1
sleep 1
## start docker compose
# Skip OAuth validation for air-gapped environments (second parameter = true)
startDockerCompose false true

setProtocol
source ./helper.sh

########### testing for ui, couchDB and liberty containers are running #######
header "Checking Pods are running"
checkUIPodRunning
checkDBPodRunning
checkNeo4jPodRunning
checkAdvisorPodRunning
##############################################################################

displayTARunningStatus
