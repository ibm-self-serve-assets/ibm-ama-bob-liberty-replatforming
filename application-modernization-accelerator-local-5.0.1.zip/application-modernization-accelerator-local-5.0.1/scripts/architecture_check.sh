#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

# Architecture compatibility check for container images

source ./logging.sh

# Get the host architecture
get_host_architecture() {
    local arch=$(uname -m)
    case "$arch" in
        x86_64)
            echo "amd64"
            ;;
        aarch64|arm64)
            echo "arm64"
            ;;
        armv7l)
            echo "arm/v7"
            ;;
        ppc64le)
            echo "ppc64le"
            ;;
        s390x)
            echo "s390x"
            ;;
        *)
            echo "$arch"
            ;;
    esac

}

# Get the architecture of a container image
get_image_architecture() {
    local image_name="$1"
    
    if [[ -z "$image_name" ]]; then
        echo "Error: No image name provided" >&2
        return 1
    fi
    
    # Try to inspect the image and get its architecture
    local arch=$(docker inspect --format='{{.Architecture}}' "$image_name" 2>/dev/null)
    
    if [[ -z "$arch" ]]; then
        # If docker inspect fails, the image might not be loaded yet
        return 1
    fi
    
    echo "$arch"
}

# Normalize architecture names to canonical forms
normalize_architecture() {
    local arch="$1"
    case "$arch" in
        x86_64|amd64)
            echo "amd64"
            ;;
        aarch64|arm64)
            echo "arm64"
            ;;
        i686|i386|386)
            echo "386"
            ;;
        *)
            echo "$arch"
            ;;
    esac
}

# Check if image architecture is compatible with host architecture
# Returns 0 (true) if compatible, 1 (false) if not
# Compatible with Bash 3.2+ (no associative arrays needed)
is_architecture_compatible() {
    local host="$1"
    local image="$2"
    
    # Define compatibility rules
    # arm64 can run amd64 via emulation (Rosetta 2, QEMU)
    # amd64 has no cross-platform support in this configuration
    # 386 is compatible with itself only
    
    case "$host" in
        arm64)
            # arm64 can run amd64 images via emulation
            if [[ "$image" == "amd64" ]]; then
                return 0  # Compatible
            fi
            ;;
        amd64)
            # amd64 has no cross-platform support
            return 1  # Not compatible
            ;;
        386)
            # 386 only runs 386
            return 1  # Not compatible
            ;;
    esac
    
    return 1  # Not compatible
}

# Check if an image architecture is compatible with the host
check_image_compatibility() {
    local image_name="$1"
    local host_arch=$(get_host_architecture)
    local image_arch=$(get_image_architecture "$image_name")
    
    if [[ $? -ne 0 ]] || [[ -z "$image_arch" ]]; then
        log "Warning: Could not determine architecture for image: $image_name"
        return 2  # Return 2 to indicate unknown/unable to check
    fi
    
    # Normalize architectures to canonical forms for comparison
    local normalized_host=$(normalize_architecture "$host_arch")
    local normalized_image=$(normalize_architecture "$image_arch")
    
    # Check for exact match after normalization
    if [[ "$normalized_host" == "$normalized_image" ]]; then
        log "Architecture compatible (exact match or equivalent)"
        return 0  # Compatible
    fi
    
    # Check compatibility matrix
    if is_architecture_compatible "$normalized_host" "$normalized_image"; then
        log "Architecture compatible (cross-platform support)"
        return 0  # Compatible
    fi
    
    # Incompatible
    log "Architecture incompatible"
    return 1  # Incompatible
}

# Verify all product images are compatible with the host architecture
verify_images_architecture() {
    local host_arch=$(get_host_architecture)
    local incompatible_images=()
    local unknown_images=()
    
    log "Verifying Image Architecture Compatibility"
    log "Host architecture: $host_arch"
    
    # Check each image
    local images_to_check=(
        "$TA_LOCAL_CONFIG_COUCH_IMAGE"
        "$TA_LOCAL_CONFIG_UI_IMAGE"
        "$TA_LOCAL_CONFIG_SERVER_IMAGE"
        "$TA_LOCAL_CONFIG_NEO4J_IMAGE"
    )
    
    local image_names=("DB" "UI" "ADVISOR" "NEO4J")
    
    for i in "${!images_to_check[@]}"; do
        local image="${images_to_check[$i]}"
        local name="${image_names[$i]}"
        
        check_image_compatibility "$image"
        local result=$?
        
        if [[ $result -eq 0 ]]; then
            local img_arch=$(get_image_architecture "$image")
            log "The $name image ($image) is compatible: $img_arch"
        elif [[ $result -eq 1 ]]; then
            local img_arch=$(get_image_architecture "$image")
            log "The $name image ($image) is INCOMPATIBLE: $img_arch (host: $host_arch)"
            incompatible_images+=("$name ($image): $img_arch")
        else
            log "This $name image ($image) architecture could not be determined"
            unknown_images+=("$name ($image)")
        fi
    done
    
    # Report results
    if [[ ${#incompatible_images[@]} -gt 0 ]]; then
        log "ERROR: Architecture mismatch detected!"
        log "The following images are incompatible with your system architecture ($host_arch):"
        for img in "${incompatible_images[@]}"; do
            log "  - $img"
        done
        log " Images were pulled/saved on a different architecture system or The wrong image variant was downloaded "
        log " Please Pull/save images on a system with the same architecture ($host_arch)"
        return 1
    fi
    
    if [[ ${#unknown_images[@]} -gt 0 ]]; then
        echo ""
        log "Warning: Could not verify architecture for some images:"
        for img in "${unknown_images[@]}"; do
            log "  - $img"
        done
        log "Proceeding with caution. If containers fail to start, this may be the cause."
        echo ""
    fi
    
    if [[ ${#incompatible_images[@]} -eq 0 ]] && [[ ${#unknown_images[@]} -eq 0 ]]; then
        log "All images are compatible with host architecture: $host_arch"
        echo ""
    fi
    
    return 0
}