#!/usr/bin/env bash
# Created by Huang, Fuguo (aka ken) on 18.2.2021.

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------
# Function to set AMA-specific environment variables and write to security config file
# Parameters:
#   $1 - config_file (required): Path to the security config file to use
function setAmaSpecificEnvVars() {
	local config_file="$1"
	
	# Get the parent directory if we're in scripts/, otherwise use current directory
	if [[ $(basename "$PWD") == "scripts" ]]; then
		dir_name=$(basename "$(dirname "$PWD")")
	else
		dir_name=$(basename "$PWD")
	fi
	
	# Check if running AMA based on directory name
	if [[ ${dir_name} == *"application-modernization-accelerator"* ]]; then
		# Set default values if not already set
		if [[ -z "${AMA_RBAC_ENABLED}" ]]; then
			export AMA_RBAC_ENABLED=false
		fi
		
		if [[ -z "${AMA_AUDIT_ENABLED}" ]]; then
			export AMA_AUDIT_ENABLED=false
		fi
		
		# Write to config file if not already present
		if [ -f "$config_file" ]; then
			# Check and add AMA_RBAC_ENABLED if not present
			if ! grep -q "^AMA_RBAC_ENABLED=" "$config_file"; then
				echo "" >> "$config_file"
				echo "## RBAC" >> "$config_file"
				echo "AMA_RBAC_ENABLED=${AMA_RBAC_ENABLED}" >> "$config_file"
				log "Added AMA_RBAC_ENABLED=${AMA_RBAC_ENABLED} to $(basename $config_file)"
			fi
			
			# Check and add AMA_AUDIT_ENABLED if not present
			if ! grep -q "^AMA_AUDIT_ENABLED=" "$config_file"; then
				echo "" >> "$config_file"
				echo "## AUDIT FLAG" >> "$config_file"
				echo "AMA_AUDIT_ENABLED=${AMA_AUDIT_ENABLED}" >> "$config_file"
				log "Added AMA_AUDIT_ENABLED=${AMA_AUDIT_ENABLED} to $(basename $config_file)"
			fi
		fi
		
		log "AMA-specific environment variables set: AMA_RBAC_ENABLED=${AMA_RBAC_ENABLED}, AMA_AUDIT_ENABLED=${AMA_AUDIT_ENABLED}"
	else
		# For TA, remove these variables from both oauth config files if present
		OAUTH_CONFIG=./.oauth_config
		OAUTH_CONFIG_DEV=./.oauth_config.dev

		for cfg in "$OAUTH_CONFIG" "$OAUTH_CONFIG_DEV"; do
			if [ -f "$cfg" ]; then
				# Remove AMA-specific lines from config file
				sed -i.bak '/^AMA_RBAC_ENABLED=/d' "$cfg" 2>/dev/null
				sed -i.bak '/^AMA_AUDIT_ENABLED=/d' "$cfg" 2>/dev/null
				# Remove the comment lines if they exist alone
				sed -i.bak '/^## RBAC$/d' "$cfg" 2>/dev/null
				sed -i.bak '/^## AUDIT FLAG$/d' "$cfg" 2>/dev/null
				rm -f "${cfg}.bak" 2>/dev/null
			fi
		done

		# Unset environment variables
		unset AMA_RBAC_ENABLED
		unset AMA_AUDIT_ENABLED
		log "Running Transformation Advisor - AMA-specific variables removed from config files"
	fi
}

source ./configure_oauth.sh

function importSecurityEnv() {
	if [[ ! -d "../logs" ]]; then
		mkdir ../logs
	fi

	local SECURITY_CONFIG=./.security_config
	local SECURITY_CONFIG_DEV=./.security_config.dev
	local OAUTH_CONFIG=./.oauth_config
	local OAUTH_CONFIG_DEV=./.oauth_config.dev

	# --- Source security config (TLS, ports, keys) ---
	local sec_file="$SECURITY_CONFIG"
	if [ -f "$SECURITY_CONFIG_DEV" ]; then
		log "$SECURITY_CONFIG_DEV is provided. Using security dev file."
		sec_file="$SECURITY_CONFIG_DEV"
	fi
	if [ -f "$sec_file" ]; then
		source "$sec_file"
	fi

	# --- Source oauth config (auth enabled, OIDC provider, endpoints) ---
	# OAuth auto-population/validation is handled later in installHelper.sh after
	# .env values such as the public UI URL have been fully resolved.
	local oauth_file="$OAUTH_CONFIG"
	if [ -f "$OAUTH_CONFIG_DEV" ]; then
		log "$OAUTH_CONFIG_DEV is provided. Using oauth dev file."
		oauth_file="$OAUTH_CONFIG_DEV"
	fi
	export OAUTH_CONFIG_FILE="$oauth_file"

	# default to auth disabled if no oauth config exists
	export APPMOD_AUTH_ENABLED=false
	if [ ! -f "$oauth_file" ]; then
		setAmaSpecificEnvVars "$oauth_file"
		return
	fi

	source "$oauth_file"
	setAmaSpecificEnvVars "$oauth_file"
}

# import neo4j password file
# contains neo4j password
function importNeo4jPassEnv() {
	if [[ ! -d "../logs" ]]; then
  		mkdir ../logs
	fi
	NEO4J_PASS_FILE=./.neo4j_pass

	if [ -f "$NEO4J_PASS_FILE" ]; then
		source "$NEO4J_PASS_FILE"
	fi
}

# create .neo4j_pass file containing encrypted password and key to decrypt it
function createNeo4jPassFile() {
	getOpensslVersion
	TA_LOCAL_ENCRYPTED_NEO4J_PASSWORD=$(echo $TA_LOCAL_NEO4J_PASSWORD | openssl enc -aes-256-cbc -a -k $TA_LOCAL_KEY_PASS -pbkdf2)

	cat > .neo4j_pass <<-EOF
# created on $(date +"%H:%M:%S")
TA_LOCAL_STORED_NEO4J_ENCRYPTED_PASS=$TA_LOCAL_ENCRYPTED_NEO4J_PASSWORD
TA_LOCAL_STORED_NEO4J_PASS_KEY=$TA_LOCAL_KEY_PASS
EOF
}
# decrypt neo4j password from the .neo4j_pass file and export to environment variables
function setNeo4jPassHelper() {
	getOpensslVersion
	TA_LOCAL_NEO4J_PASSWORD=$(echo $TA_LOCAL_STORED_NEO4J_ENCRYPTED_PASS | openssl enc -aes-256-cbc -d -a -k $TA_LOCAL_STORED_NEO4J_PASS_KEY -pbkdf2)
	export TA_LOCAL_NEO4J_PASSWORD=$TA_LOCAL_NEO4J_PASSWORD
	export TA_LOCAL_DECRYPT_NEO4J_PASSWORD=$TA_LOCAL_NEO4J_PASSWORD
}

# set neo4j password, either generate it or reuse it
function setNeo4jPass() {
  	if [[ -z "${TA_LOCAL_STORED_NEO4J_ENCRYPTED_PASS:-}" || -z "${TA_LOCAL_STORED_NEO4J_PASS_KEY:-}" ]]; then
  		# password not set
  		export TA_LOCAL_KEY_PASS=$pass_key
  		export TA_LOCAL_NEO4J_PASSWORD=$admin_pwd
  		createNeo4jPassFile
  	else
  		# password exists in the file
  		setNeo4jPassHelper
  	fi
}

function setDbPasswords() {
	admin_pwd=$(openssl rand -base64 29 | tr -d "=+/" | cut -c1-25)
	pass_key=$(openssl rand -base64 29 | tr -d "=+/" | cut -c1-25)
	user_pwd=$(openssl rand -base64 29 | tr -d "=+/" | cut -c1-25)
	export TA_LOCAL_COUCHDB_PASSWORD=$admin_pwd
	export TA_LOCAL_DB_PASSWORD=$admin_pwd
	export TA_LOCAL_TA_DB_NONADMIN_PASSWORD=$user_pwd

	# Neo4J
	# set random password only if the stored file is not present, or the key is not present or wrong key
	# $NEO4J_PASS and $TA_LOCAL_STORED_NEO4J_PASS_KEY are set by importNeo4jPassEnv
	setNeo4jPass
}

# return openssl version in digits only
# e.g. OpenSSL 1.1.1i  8 Dec 2020 will return 111
function getOpensslVersion() {
	v=$(openssl version | awk '{print $2}')

	local IFS=".$IFS"

	read majar minor patch <<<"$v"

	# grep digits from string
	patch_1=$(echo $patch | grep -o '[0-9]\+')

	export TA_TEMP_CURRENT_OPENSSL_VERSION="$majar$minor$patch_1"
}

function setApiKey() {
	if [[ -z "${TA_API_KEY}" ]]; then
		# TA_API_KEY is unset, will generate this value
		ta_api_key=$(openssl rand -base64 29 | tr -d "=+/" | cut -c1-25)
		export TA_API_KEY=$ta_api_key
	fi
}

function setAesKeyIV() {

	getOpensslVersion

	if [[ -z "$TA_AES_IV" || -z "$TA_AES_KEY" ]]; then
		key_iv_pair=$(openssl enc -d -a -aes-256-cbc -pbkdf2 -nosalt -P -pass pass:${TA_API_KEY} | tr -d '\n')
		
		# Set the delimiter
		IFS='iv ='

		#Read the split strings into an array based on the delimiter
		read -a string_array <<<"$key_iv_pair"
		# sample out put
		# key=E9FDB9B39A0D0E66BEB70DDBBF48CA9C908313E986C45D24FAA7E1D5347D7651iv =DEE4909389A4CD1E200A4A56A7AFD389
		# key
		# E9FDB9B39A0D0E66BEB70DDBBF48CA9C908313E986C45D24FAA7E1D5347D7651
		#
		#
		# DEE4909389A4CD1E200A4A56A7AFD389
		export TA_AES_KEY=${string_array[1]}
		export TA_AES_IV=${string_array[4]}
		unset IFS
	fi
}

# Made with Bob
