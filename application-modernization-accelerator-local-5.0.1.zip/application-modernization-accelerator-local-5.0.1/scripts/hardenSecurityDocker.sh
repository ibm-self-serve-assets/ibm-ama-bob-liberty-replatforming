#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts to close down non-essential egress ports in the docker network
sudo iptables -I DOCKER -o ta_local -j DROP
sudo iptables -I DOCKER -o ta_local -p tcp -m multiport --dport 53,80,443,3000,3443,9080,9443,5984,6984,7687 -j ACCEPT
sudo iptables -I DOCKER -o ta_local -p tcp -m multiport --sport 53,80,443,3000,3443,9080,9443,5984,6984,7687 -j ACCEPT
sudo iptables -I DOCKER -o ta_local -p udp --sport 53 -j ACCEPT
sudo iptables -I DOCKER -o ta_local -p udp --dport 53 -j ACCEPT
