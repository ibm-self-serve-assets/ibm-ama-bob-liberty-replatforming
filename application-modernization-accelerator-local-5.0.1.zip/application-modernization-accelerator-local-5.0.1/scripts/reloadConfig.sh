#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"


###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi


source ./stopLocalPods.sh
sleep 1

## stop  processes 

stopLocalPods

## remove the  Pods

removePods

## Remove config file hash file - used for reconfiguration check
rm -rf ./.configuration_file_hash
