#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

#clean up before install

mkdir -p ../logs


./cleanBeforeInstall.sh >../logs/uninstall_$(date +"%Y%m%d_%H%M%S").log

./copy_back_files.sh
