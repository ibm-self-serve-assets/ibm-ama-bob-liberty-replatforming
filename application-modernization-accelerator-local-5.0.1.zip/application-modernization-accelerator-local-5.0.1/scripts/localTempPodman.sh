#!/bin/bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# --------------------------------------------- 

###create the podman/docker alias
if [[ ${TA_LOCAL_TEMP_PODMAN_INSTALL} = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi