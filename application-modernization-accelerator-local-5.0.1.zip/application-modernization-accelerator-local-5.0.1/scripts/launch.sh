#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------


#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"
source ./logging.sh
source ./spinner.sh
source ./input_validation.sh

source ./.security_config
source ./.oauth_config

###create the podman/docker alias
source ./createPodmanAlias.sh
source ./container_manager_utils.sh

# Get saved preference if it exists
preference=$(get_container_manager_preference)
createPodmanAlias "$preference"
source ./enableSecurity.sh
# Note: importSecurityEnv is not needed here as .security_config is already sourced above (line 16)
# Calling it here causes duplicate OAuth auto-population during installation
# importSecurityEnv is called in installHelper.sh where it's actually needed
# importSecurityEnv
source ./checkPodsRunning.sh
source ./imageHelper.sh
source ./secretHelper.sh
source ./findHost.sh
source ./launch_utils.sh
source ./configuration_utils.sh

# Check if required ports are available (fail fast)
# Skip port check if containers are already running
set_image_status
ui=$(get_ui_id)
couch=$(get_db_id)
server=$(get_server_id)
neo4j=$(get_graph_id)
if [[ "$image_status" == "all-present" ]]; then

		if [ -z $server ] && [ -z $ui ] && [ -z $couch ] && [ -z $neo4j ]; then
		check_ports_available
		fi
fi

function stopLaunch(){
	to_terminal "\n\t%s" "Interrupted, stopping launch of ${PRODUCT_NAME}"
	exit 1
}


function fullUninstall(){
	./cleanUpBeforeInstall.sh
	rm -rf ../data
	rm -rf ../graph_data
	rm -rf ./.neo4j_pass
	rm -rf ../.license_accepted
	./copy_back_files.sh
	removeVolumes
	rm -rf ../key
	rm -rf ../swidtag
}

function partialUninstall(){
	./cleanUpBeforeInstall.sh
	rm -rf ../.license_accepted
	./copy_back_files.sh
	rm -rf ../key
	rm -rf ../swidtag
}

# if does not contain "command not found", we have docker
if [[ ${TA_LOCAL_TEMP_DOCKER_INSTALL:-false} = true ]]; then
	echo ""
	if uname -s | grep 'Darwin' >/dev/null; then
		sed -i '' 's/TA_READ_VALUE_FROM_ENV_VAR=false/TA_READ_VALUE_FROM_ENV_VAR=true/g' .env
		sed -i '' 's/TA_READ_VALUE_FROM_ENV_VAR=false/TA_READ_VALUE_FROM_ENV_VAR=true/g' .env_orig
	else
		sed -i 's/TA_READ_VALUE_FROM_ENV_VAR=false/TA_READ_VALUE_FROM_ENV_VAR=true/g' .env
		sed -i 's/TA_READ_VALUE_FROM_ENV_VAR=false/TA_READ_VALUE_FROM_ENV_VAR=true/g' .env_orig
	fi
	echo ""
elif [[ ${TA_LOCAL_TEMP_PODMAN_INSTALL:-false} = true ]]; then
	echo ""
	echo ""
fi

reconfigure_local_config(){
	header "Re-initializing Configuration"
	removeConfigSecrets
	# If .oauth_config has changed since last install, clear the OIDC secrets so
	# the user is prompted to re-enter the Client ID and Secret for the new provider.
	if _oauth_config_hash_changed; then
		to_terminal "${BLUE}${STATUS_INFO_SYMBOL}${RESET} OAuth configuration changed — clearing OIDC credentials"
		removeOidcSecrets
	fi
	rm -f ./.configuration_file_hash
	run_with_spinner "./reloadConfig.sh" "Cleaning up before re-initializing ${PRODUCT_NAME} configuration" "Cleaning" "CLEANED"
	./copy_back_files.sh
	./installLocal.sh
	local install_exit_code=$?
	if [[ $install_exit_code -ne 0 ]]; then
		to_terminal ""
		to_terminal "${RED}Installation failed due to configuration errors.${RESET}"
		to_terminal "Please fix the errors above and try again."
		to_terminal ""
		return 1
	fi
	sleep 3
	save_config_hash_in_file
	./renameDockerName.sh &>/dev/null
}

image_and_pod_check_for_launch(){
	set_image_status
	ui=$(get_ui_id)
	couch=$(get_db_id)
	server=$(get_server_id)
	neo4j=$(get_graph_id)
	if [[ "$image_status" == "all-present" ]]; then
		if ! ( host_matches_env_file && check_configuration_file_hash) ; then
			# there is a mis match in the host IP and the IP in our env file. Let's reconfigure
			reconfigure_local_config
			local reconfig_exit_code=$?
			if [[ $reconfig_exit_code -ne 0 ]]; then
				return 1
			fi
			return 0
		fi

		if [ -z $server ] || [ -z $ui ] || [ -z $couch ] || [ -z $neo4j ]; then
			status_header
			to_terminal "${PRODUCT_NAME} images installed but not running."
			to_terminal "Please select option 5 to start ${PRODUCT_NAME} or option 8 if the config has changed."
		else
			# if TA is running, display the status

			# set the protocol, reset the protocol, as startDockerCompose set to something else
			PROTOCOL=http
			# translate into lower case
			TA_AUTH_ENABLE_TLS_lower_case=$(echo "$TA_AUTH_ENABLE_TLS" | tr '[:upper:]' '[:lower:]')

			if [[ $TA_AUTH_ENABLE_TLS_lower_case == 'true' ]]; then
				PROTOCOL=https
			fi

			# this will print dots like ... in a background job
			source ./helper.sh
			# showConfiguringTA "Checking Status.."
			header "Checking Status of pods"

			########### testing for ui, couchDB and liberty containers are running #######
			checkUIPodRunning
			checkDBPodRunning
			checkNeo4jPodRunning
			checkAdvisorPodRunning
			##############################################################################
			# Save config file
			save_config_hash_in_file

			displayTARunningStatus
		fi
	fi
}

image_and_pod_check_for_launch


#If an argument is passed in, then use it and dont wait for prompt response
if [[ ! -z ${1:-} ]]; then
	OPERATION=$1
	if [[ $OPERATION -gt 0 ]] && [[ $OPERATION -lt 10 ]] ; then
		log "COMMAND LINE OPERATION SELECTED: $1"
	else
		to_terminal "INVALID OPERATION SELECTED: $1"
	fi
else
	header "Select the operation"
	prompt_and_read "
	\t1) Install ${PRODUCT_NAME}\n
	\t2) Uninstall ${PRODUCT_NAME} (keep database data)\n
	\t3) Uninstall ${PRODUCT_NAME} (remove database data)\n
	\t4) Stop ${PRODUCT_NAME} \n
	\t5) Start ${PRODUCT_NAME} \n
	\t6) Check for latest ${PRODUCT_NAME} \n
	\t7) Working in an Air Gapped Environment\n
	\t8) Re-initialize Configuration\n
	\t9) Run Debug Report\n
	\tq) Quit\n " OPERATION
	basic_input_validation $OPERATION 1 9
fi

case $OPERATION in
1)
	run_with_spinner "./cleanUpBeforeInstall.sh" "Cleaning up before installing ${PRODUCT_NAME}" "Cleaning" "CLEANED"
	./installLocal.sh
	install_exit_code=$?
	if [[ $install_exit_code -ne 0 ]]; then
		exit 1
	fi
	sleep 3
	save_config_hash_in_file
	./renameDockerName.sh&>/dev/null
	;;
2)
	run_with_spinner partialUninstall "Uninstalling ${PRODUCT_NAME}" "Uninstalling"
	#Remove after spinner so print can complete
	rm -rf ../logs
	;;
3)
	run_with_spinner fullUninstall "Uninstalling ${PRODUCT_NAME}" "Uninstalling"
	#Remove after spinner so print can complete
	rm -rf ../logs
	;;
4)
	# to_terminal  "Stopping ${PRODUCT_NAME} ..."
	run_with_spinner ./stopLocal.sh "Stopping ${PRODUCT_NAME}" "Stopping" "STOPPED"
	status_header
	to_terminal "${PRODUCT_NAME} processes are stopped."
	;;
5)
	header "Starting ${PRODUCT_NAME}"
	./startLocal.sh
	;;
6)
	# to_terminal  "Checking if newer version of ${PRODUCT_NAME} is available..."
	./checkforLatest.sh
	;;
7) 
	header "Air-gap Installation"
	./fileImages.sh 
	;;
8)
	reconfigure_local_config
	reconfig_exit_code=$?
	if [[ $reconfig_exit_code -ne 0 ]]; then
		exit 1
	fi
	;;

9)  
    date=$(date +"%Y.%m.%d")
	local_info="${SHORT_NAME}LocalInfo/${SHORT_NAME}LocalInfo_$date.txt"
	message_log="${SHORT_NAME}LocalInfo/message.log_$date.txt"
	run_with_spinner "./getLocalEnvInfo.sh ${local_info} ${message_log}" "Generating debug report for ${PRODUCT_NAME}" "Creating report" "CREATED"
	line_break
	to_terminal "Local Debug log is available at ${local_info}"
	to_terminal "Local Message log is available at ${message_log}"
	line_break
	;;

q) exit ;;
esac

