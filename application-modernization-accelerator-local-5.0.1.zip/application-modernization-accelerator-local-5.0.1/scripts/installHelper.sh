#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

# Created by Huang, Fuguo (aka ken) on 19.2.2021.

source ./localTempPodman.sh
source ./enableSecurity.sh
source ./enableTls.sh
source ./configure_oauth.sh

source ./imageHelper.sh
#source ./.configuration


TA_LOCAL_CONFIG=./.configuration
TA_LOCAL_CONFIG_DEV=./.configuration.dev
TA_LOCAL_CONFIG_DEV_VAR=./.configuration.dev
source ./helper.sh
sourceConfig

sync_oauth_callback() {
	local security_config_file="${OAUTH_CONFIG_FILE:-./.oauth_config}"
	local ta_public_ui_url
	local ta_callback_uri
	local derived_callback_uri

	# OAuth callback URI belongs in the selected security config, but it depends on
	# the final resolved public UI URL. Read from shell variables here because
	# updateUiEnv() keeps TA_PUBLIC_ACCESSIBLE_UI_URL synchronized in memory as well.
	[[ ! -f "$security_config_file" ]] && return 0

	ta_public_ui_url="${TA_PUBLIC_ACCESSIBLE_UI_URL:-}"
	ta_callback_uri="${TA_AUTH_OIDC_CALLBACK_URI:-}"

	[[ -z "$ta_public_ui_url" ]] && return 0

	if [[ -n "$ta_callback_uri" ]] && [[ "$ta_callback_uri" != "sample" ]] && [[ "$ta_callback_uri" != "test" ]] && [[ "$ta_callback_uri" != "placeholder" ]]; then
		return 0
	fi

	derived_callback_uri="${ta_public_ui_url%/}/auth/callback"

	# Ensure OAuth section header exists before writing OAuth variables
	ensure_oauth_section_header "$security_config_file"

	# Keep the shell environment aligned with the derived callback URI so the
	# subsequent validation step reads the same value that was written to the
	# selected security config file.
	TA_AUTH_OIDC_CALLBACK_URI="$derived_callback_uri"
	export TA_AUTH_OIDC_CALLBACK_URI
	update_config_variable "TA_AUTH_OIDC_CALLBACK_URI" "$derived_callback_uri" "$security_config_file"

	log "Auto-populated TA_AUTH_OIDC_CALLBACK_URI in ${security_config_file} from TA_PUBLIC_ACCESSIBLE_UI_URL"
}

populate_oauth() {
	local security_config_file="${OAUTH_CONFIG_FILE:-./.oauth_config}"

	# OAuth auto-population must happen after .env placeholders are resolved so the
	# callback URI can first be synchronized into the selected security config from
	# the final UI URL.
	[[ "${APPMOD_AUTH_ENABLED}" != "true" ]] && return 0
	[[ ! -f "$security_config_file" ]] && return 0

	sync_oauth_callback
	# If .oauth_config changed since last install (e.g. new provider/issuer),
	# clear existing OIDC secrets so the user is prompted for fresh credentials.
	if _oauth_config_hash_changed; then
		removeOidcSecrets
	fi
	create_oidc_secrets || return 1
	OAUTH_CONFIG_FILE="$security_config_file" auto_populate_oauth
	source "$security_config_file"
	export TA_AUTH_OIDC_CALLBACK_URI="${TA_AUTH_OIDC_CALLBACK_URI:-}"
}

append_oauth_env() {
	NOT_SET_STRING="NOT_SET"
	cat >> .env <<-EOF
APPMOD_AUTH_ENABLED=${APPMOD_AUTH_ENABLED}
TA_AUTH_IDENTITY_REQUEST_ENDPOINT=${TA_AUTH_IDENTITY_REQUEST_ENDPOINT}
TA_USE_SECURE_COOKIE=${TA_USE_SECURE_COOKIE}
TA_AUTH_IDENTITY_REQUEST_ENDPOINT_PATH=${TA_AUTH_IDENTITY_REQUEST_ENDPOINT_PATH}
TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE=${TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE}
TA_AUTH_CALLBACK_STATE_PREFIX_PADDING=${TA_AUTH_CALLBACK_STATE_PREFIX_PADDING}
TA_AUTH_TOKEN_REQUEST_ENDPOINT=${TA_AUTH_TOKEN_REQUEST_ENDPOINT}
TA_AUTH_TOKEN_REQUEST_ENDPOINT_PATH=${TA_AUTH_TOKEN_REQUEST_ENDPOINT_PATH}
TA_AUTH_TOKEN_VERIFICATION_ENDPOINT=${TA_AUTH_TOKEN_VERIFICATION_ENDPOINT}
TA_AUTH_TOKEN_VERIFICATION_ENDPOINT_PATH=${TA_AUTH_TOKEN_VERIFICATION_ENDPOINT_PATH}
TA_AUTH_TOKEN_REVOCATION_ENDPOINT=${TA_AUTH_TOKEN_REVOCATION_ENDPOINT}
TA_AUTH_TOKEN_REVOCATION_ENDPOINT_PATH=${TA_AUTH_TOKEN_REVOCATION_ENDPOINT_PATH}
TA_AUTH_END_SESSION_ENDPOINT=${TA_AUTH_END_SESSION_ENDPOINT}
TA_AUTH_END_SESSION_ENDPOINT_PATH=${TA_AUTH_END_SESSION_ENDPOINT_PATH}
TA_AUTH_OIDC_CALLBACK_URI=${TA_AUTH_OIDC_CALLBACK_URI}
TA_OCP_API_ENDPOINT=${TA_OCP_API_ENDPOINT}
TA_SERVER_PORT=${TA_LOCAL_INTERNAL_SERVER_PORT}
TA_UI_PORT=${TA_LOCAL_INTERNAL_UI_PORT}
TA_DB_PORT=${TA_LOCAL_INTERNAL_DB_PORT}
TA_REC_AUTO_GENERATE=false
AMA_RBAC_ENABLED=${AMA_RBAC_ENABLED}
AMA_AUDIT_ENABLED=${AMA_AUDIT_ENABLED}
EOF
}

function startDockerCompose {

  # first argument, set to true if you want to pull docker images
	shouldPullImages=$1
	# second argument, set to true to skip OAuth validation (for air-gapped environments)
	skipOAuthValidation=$2

	# enable security environment, if conditions are met.
	importSecurityEnv
	importNeo4jPassEnv

	# translate into lower case
	TA_AUTH_ENABLE_TLS_lower_case=$(echo "$TA_AUTH_ENABLE_TLS" | tr '[:upper:]' '[:lower:]')

	if [[ $TA_AUTH_ENABLE_TLS_lower_case == 'true' ]]; then
		enableTls
		updateProtocol https
		updateNeo4JEnv true bolt+ssc OPTIONAL
		updateSecureCookie true
		export TA_USE_SECURE_COOKIE=true
		
	else
		# set env vars to non-TLS ports
		updateProtocol http
		updateNeo4JEnv false bolt DISABLED
		updateSecureCookie false
		export TA_USE_SECURE_COOKIE=false

	fi

	# replace placeholders in the env file to real values
	updateLibertyEnv
	updateUiEnv

	# set couch db passwords
	setDbPasswords

	# set API Key
	setApiKey

	# run setAesKeyIV, only when auth is enabled
	if [[ ${APPMOD_AUTH_ENABLED} == 'true' ]]; then
		# set AES key and IV
		setAesKeyIV
	fi

	if [ ! -d "../data" ]; then
		mkdir ../data
		chmod ugo+rwx ../data
	fi

	if [ ! -d "../graph_data" ]; then
		mkdir ../graph_data
		chmod ugo+rwx ../graph_data
	fi


	#echo "APPMOD_AUTH_ENABLED: $APPMOD_AUTH_ENABLED"
	#echo "TA_AUTH_IDENTITY_REQUEST_ENDPOINT: $TA_AUTH_IDENTITY_REQUEST_ENDPOINT"
	#echo "TA_AUTH_TOKEN_VERIFICATION_ENDPOINT $TA_AUTH_TOKEN_VERIFICATION_ENDPOINT"
	#echo "TA_AUTH_IDENTITY_REQUEST_ENDPOINT: $TA_AUTH_IDENTITY_REQUEST_ENDPOINT"
	#echo "TA_AUTH_IDENTITY_REQUEST_ENDPOINT_PATH: $TA_AUTH_IDENTITY_REQUEST_ENDPOINT_PATH"
	#echo "TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE: $TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE"
	#echo "TA_AUTH_CALLBACK_STATE_PREFIX_PADDING: $TA_AUTH_CALLBACK_STATE_PREFIX_PADDING"

	#echo "TA_AUTH_TOKEN_REQUEST_ENDPOINT: $TA_AUTH_TOKEN_REQUEST_ENDPOINT"
	#echo "TA_AUTH_TOKEN_REQUEST_ENDPOINT_PATH: $TA_AUTH_TOKEN_REQUEST_ENDPOINT_PATH"

	#echo "TA_AUTH_TOKEN_VERIFICATION_ENDPOINT: $TA_AUTH_TOKEN_VERIFICATION_ENDPOINT"
	#echo "TA_AUTH_TOKEN_VERIFICATION_ENDPOINT_PATH: $TA_AUTH_TOKEN_VERIFICATION_ENDPOINT_PATH"

	#echo "TA_AUTH_OIDC_CALLBACK_URI: $TA_AUTH_OIDC_CALLBACK_URI"
	#echo "TA_PUBLIC_ACCESSIBLE_API_SERVER_URL: $TA_PUBLIC_ACCESSIBLE_API_SERVER_URL"
	#echo "TA_LOCAL_API_SERVER: $TA_LOCAL_API_SERVER"

	#echo "TA_AUTH_OIDC_CALLBACK_URI: $TA_AUTH_OIDC_CALLBACK_URI"
	#echo "TA_AUTH_OIDC_CLIENT_ID: $TA_AUTH_OIDC_CLIENT_ID"
	#echo "TA_AUTH_OIDC_CLIENT_SECRET: $TA_AUTH_OIDC_CLIENT_SECRET"
	#echo "TA_LOCAL_INTERNAL_SERVER_PORT: $TA_LOCAL_INTERNAL_SERVER_PORT"
	#echo "TA_LOCAL_INTERNAL_UI_PORT: $TA_LOCAL_INTERNAL_UI_PORT"
	#echo "TA_LOCAL_INTERNAL_DB_PORT: $TA_LOCAL_INTERNAL_DB_PORT"

#	echo "TA_LOCAL_COUCHDB_PASSWORD: $TA_LOCAL_COUCHDB_PASSWORD"
#	echo "TA_LOCAL_DB_PASSWORD: $TA_LOCAL_DB_PASSWORD"
#	echo "TA_LOCAL_TA_DB_NONADMIN_PASSWORD: $TA_LOCAL_TA_DB_NONADMIN_PASSWORD"

	#echo "TA_API_KEY: $TA_API_KEY"
	#echo "TA_AES_IV: $TA_AES_IV"
	#echo "TA_AES_KEY: $TA_AES_KEY"

#	echo "TA_LOCAL_NEO4J_PASSWORD: $TA_LOCAL_NEO4J_PASSWORD"
#	echo "TA_LOCAL_NEO4J_USER: $TA_LOCAL_NEO4J_USER"
#	echo "NEO4J_USER: $NEO4J_USER"

	# this is the way to passing in the environments into
	# overwrite TA_LOCAL_TA_AUTH_OIDC_CALLBACK_URI
	#TA_LOCAL_TA_AUTH_OIDC_CALLBACK_URI=https://localhost:3443/auth/callback \
	#TA_LOCAL_TA_AUTH_OIDC_CALLBACK_URI=http://localhost:3000/auth/callback \

# TA_READ_VALUE_FROM_ENV_VAR determine whether reading the sensitive value from .env or podman secret
# If TA_READ_VALUE_FROM_ENV_VAR is empty or false, and user is using podman, then create podman secret for the data
# Otherwise, add the data to .env file
ta_read_value_from_env_var=`grep TA_READ_VALUE_FROM_ENV_VAR .env | cut -d'=' -f 2- | awk '!/^[[:space:]]*$/'`
if [[ -z "${ta_read_value_from_env_var}" || "${ta_read_value_from_env_var}" == false ]] && [[ "${TA_LOCAL_TEMP_PODMAN_INSTALL}" == true ]]; then
	source ./secretHelper.sh
	checkAndCreateTaSecret
else
	cat >> .env <<-EOF
	COUCHDB_PASSWORD=$TA_LOCAL_COUCHDB_PASSWORD
	TA_DB_PASSWORD=$TA_LOCAL_DB_PASSWORD
	TA_DB_NONADMIN_PASSWORD=$TA_LOCAL_TA_DB_NONADMIN_PASSWORD
	TA_AUTH_OIDC_CLIENT_ID=$TA_AUTH_OIDC_CLIENT_ID
	TA_AUTH_OIDC_CLIENT_SECRET=$TA_AUTH_OIDC_CLIENT_SECRET
	TA_API_KEY=$TA_API_KEY
	TA_AES_IV=$TA_AES_IV
	TA_AES_KEY=$TA_AES_KEY
	TA_PRIVATE_KEY=$TA_PRIVATE_KEY
	TA_PUBLIC_KEY=$TA_PUBLIC_KEY
	NEO4J_AUTH=neo4j/${TA_LOCAL_NEO4J_PASSWORD}
	NEO4J_USER=neo4j
	NEO4J_PASS=${TA_LOCAL_NEO4J_PASSWORD}
	EOF
fi

# Auto-populate OAuth configuration after .env placeholders have been resolved.
populate_oauth || return 1
append_oauth_env

# Validate OAuth configuration before proceeding with installation.
# Skip for air-gapped environments where OAuth servers may not be reachable during install.
if [[ "${skipOAuthValidation}" != "true" ]]; then
	if ! validate_oauth; then
		return 1
	fi
else
	terminal_warn_notification_with_content "skip-oauth-validation" "Skipping OAuth validation for air-gapped installation"
	log "   Ensure OAuth configuration is correct before runtime"
fi

if [[ $shouldPullImages == 'true' ]]; then
  	if [ -f "$TA_LOCAL_CONFIG_DEV_VAR" ]; then
    	log "$TA_LOCAL_CONFIG_DEV_VAR is provided. Logging into staging so we can use the dev file."
    	./.login.dev.sh $TA_LOCAL_TEMP_PODMAN_INSTALL
 	fi
	imagePull
fi

if [[ $TA_LOCAL_ROUTE_HOST == true ]] ; then
	routeViaHost
else
	run_with_spinner "imageRun" "Running Images" "Running Images" "STARTED"
fi

}


function setProtocol(){
	# set the protocol, reset the protocol, as startDockerCompose set to something else
	PROTOCOL=http
	# translate into lower case
	TA_AUTH_ENABLE_TLS_lower_case=$(echo "$TA_AUTH_ENABLE_TLS" | tr '[:upper:]' '[:lower:]')
	if [[ $TA_AUTH_ENABLE_TLS_lower_case == 'true' ]]; then
		PROTOCOL=https
	fi
}