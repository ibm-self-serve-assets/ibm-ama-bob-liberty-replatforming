#!/bin/bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2025
# --------------------------------------------- 


TA_LOCAL_CONFIG=scripts/.configuration
TA_LOCAL_CONFIG_DEV=scripts/.configuration.dev
TA_CONFIG=

# if there is dev file, use it
if [ -f "$TA_LOCAL_CONFIG_DEV" ]; then
  TA_CONFIG=$TA_LOCAL_CONFIG_DEV
else
  TA_CONFIG=$TA_LOCAL_CONFIG
fi

check_ui_port_privilege() {
    # Check if UI port is set to 443 (privileged port)
    # returns 0 if port 443 is found
    # returns 1 if not found
    grep -q "^[[:space:]]*TA_EXTERNAL_UI_PORT[[:space:]]*=[[:space:]]*443" "$TA_CONFIG"
    return $?
}

update_ui_port(){
    # update TA_EXTERNAL_UI_PORT from 443 to 3000 for rootless run
    if check_ui_port_privilege; then
        if uname -s | grep 'Darwin' >/dev/null; then
            sed -i '' "s/TA_EXTERNAL_UI_PORT=443/TA_EXTERNAL_UI_PORT=3000/g" "$TA_CONFIG"
        else
            sed -i "s/TA_EXTERNAL_UI_PORT=443/TA_EXTERNAL_UI_PORT=3000/g" "$TA_CONFIG"
        fi
    fi
}

enable_lingering(){
    loginctl enable-linger "$UID"
}

create_policy(){
    SYSTEM_POLICY_FILE="/etc/containers/policy.json"
    if [[ -f "$SYSTEM_POLICY_FILE" ]]; then
        log "Copying system Podman policy.json to $PODMAN_POLICY_FILE"
        mkdir -p "$(dirname "$PODMAN_POLICY_FILE")"
        cp "$SYSTEM_POLICY_FILE" "$PODMAN_POLICY_FILE"
    else
        log "Warning: System policy file $SYSTEM_POLICY_FILE not found. Podman may not work correctly."
    fi

}


# Podman requires lingering to be enabled for rootless containers to persist beyond the user's login session
should_linger_be_enabled(){
    local user="${1:-$USER}"  # Use provided user or default to current user
    # check if linux
    # Skip check if not Linux
    if [[ "$(uname -s)" != "Linux" ]]; then
        log "Not running on Linux. Skipping lingering check."
        return 0
    fi

    # Skip check if running as root (lingering not needed for rootful Podman)
    if [[ $EUID -eq 0 ]]; then
        log "Running as root. Lingering not required. Skipping check."
        return 0
    fi

    # Skip if Podman is not available 
    if ! command -v podman &>/dev/null; then
        log "Podman is not installed. Skipping lingering check."
        return 0
    fi
    local status=$(loginctl show-user "$user" --property=Linger --value 2>/dev/null)
    log "Lingering should be anabled, linger status is $status, if there is no status check login with 'loginctl show-user'"
    [[ "$status" == "yes" ]]
}

check_policy_json_present(){
    # Use XDG_CONFIG_HOME if set, otherwise default to ~/.config
    XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
    PODMAN_POLICY_FILE="$XDG_CONFIG_HOME/containers/policy.json"
    # 0 true - file exists
    # 1 false - files does not exist
    [[ -f "$PODMAN_POLICY_FILE" ]]
    return $?
}

check_resources_enabled() {
    # Check if UI port is set to 443 (privileged port)
    # returns 0 if true is found
    # returns 1 if not found
    grep -q "^[[:space:]]*RESOURCES[[:space:]]*=[[:space:]]*true" "$TA_CONFIG"
    return $?
}

update_resources(){
    # update RESOURCES from true to false for rootless run
    if check_resources_enabled; then
        if uname -s | grep 'Darwin' >/dev/null; then
            sed -i '' "s/RESOURCES=true/RESOURCES=false/g" "$TA_CONFIG"
        else
            sed -i "s/RESOURCES=true/RESOURCES=false/g" "$TA_CONFIG"
        fi
    fi
}
is_mac_os() {
	if [[ "$OSTYPE" == "darwin"* ]]; then
		return 0
	else
		return 1
	fi
}



check_configuration_file_hash(){
    #read file `.configuration_file_hash` by line and check by file `.configuration`,`.env` and `.security_config`
    if [[ -f "./.configuration_file_hash" ]]; then
        IFS=$'\n' read -r -d '' -a lines < ./.configuration_file_hash
        for line in "${lines[@]}"; do
            file_hash=$(echo "$line" | awk '{print $1}')
            file_name=$(echo "$line" | awk '{print $2}')
            if is_mac_os; then
                current_hash=$(shasum -a 256 "$file_name" | awk '{print $1}')
            else
                current_hash=$(sha256sum "$file_name" | awk '{print $1}')
            fi
            
            if [[ "$file_hash" == "$current_hash" ]]; then
                log "File $file_name hash matches, no need to reconfigure."
                continue
            else
                status_header
                to_terminal "Configuration change detected - start reconfiguration"
                log "File $file_name hash = $file_hash does not match current hash $current_hash, reconfiguring..."
        		rm -f ./.configuration_file_hash
                return 1
            fi
        done
    else
        status_header
        to_terminal "Configuration change detected - start reconfiguration"
		log "Configuration file hash file (configuration_file_hash) not found, reconfiguring..."
        return 1
    fi

}

# Returns 0 (true) if .oauth_config exists in the hash file and its hash has changed,
# or if there is no hash file yet (first run). Returns 1 if unchanged or not tracked.
_oauth_config_hash_changed(){
    [[ ! -f "./.configuration_file_hash" ]] && return 0
    [[ ! -f "./.oauth_config" ]] && return 1

    local stored_hash
    stored_hash=$(grep " \./.oauth_config$" ./.configuration_file_hash 2>/dev/null | awk '{print $1}')
    [[ -z "$stored_hash" ]] && return 0   # not previously tracked — treat as changed

    local current_hash
    if is_mac_os; then
        current_hash=$(shasum -a 256 ./.oauth_config | awk '{print $1}')
    else
        current_hash=$(sha256sum ./.oauth_config | awk '{print $1}')
    fi

    [[ "$stored_hash" != "$current_hash" ]]
}

save_config_hash_in_file(){
    if [[ ! -f "./.configuration_file_hash" ]]; then
        touch ./.configuration_file_hash

        if is_mac_os; then
            shasum -a 256 ./.configuration ./.env ./.security_config ./.oauth_config | while read -r line; do
                echo "$line" >> ./.configuration_file_hash
            done
        else
            sha256sum ./.configuration ./.env ./.security_config ./.oauth_config | while read -r line; do
                echo "$line" >> ./.configuration_file_hash
            done
        fi

        log "Created configuration file hash file (.configuration_file_hash)"
    fi
}

check_ports_available() {
    # Check if required ports are available before starting containers
    local ports_to_check=()
    local unavailable_ports=()
    
    # Extract ports from .configuration (used in pod create command)
    if [[ -f "$TA_CONFIG" ]]; then
        local ui_port=$(grep "^[[:space:]]*TA_EXTERNAL_UI_PORT[[:space:]]*=" "$TA_CONFIG" | grep -v "^#" | tail -1 | sed 's/.*=\s*//')
        local server_port=$(grep "^[[:space:]]*TA_EXTERNAL_PORT_SERVER[[:space:]]*=" "$TA_CONFIG" | grep -v "^#" | tail -1 | sed 's/.*=\s*//')
        [[ -n "$ui_port" ]] && ports_to_check+=("$ui_port")
        [[ -n "$server_port" ]] && ports_to_check+=("$server_port")
    fi
    
    # Check for hardcoded ports when .machine_name exists (Windows Podman Desktop scenario)
    if [[ -f "./.machine_name" ]]; then
        ports_to_check+=("2222" "7474" "7687" "2220" "3000")
    fi

    # Check each port
    for port in "${ports_to_check[@]}"; do
        if command -v lsof &>/dev/null; then
            if lsof -Pi :$port -sTCP:LISTEN -t >/dev/null 2>&1; then
                unavailable_ports+=("$port")
            fi
        elif command -v netstat &>/dev/null; then
            if netstat -an | grep -q "[:.]$port.*LISTEN"; then
                unavailable_ports+=("$port")
            fi
        else
            log "Warning: Neither lsof nor netstat available. Skipping port check."
            return 0
        fi
    done
    
    # Report unavailable ports
    if [[ ${#unavailable_ports[@]} -gt 0 ]]; then
        to_terminal "Error: The following required ports are already in use:"
        for port in "${unavailable_ports[@]}"; do
            to_terminal "  - Port $port"
        done
        to_terminal "Please free these ports  or update the variables 'TA_EXTERNAL_UI_PORT' & 'TA_EXTERNAL_PORT_SERVER' in '.configuration'"
        exit 1
    fi
    
    log "All required ports are available."
    return 0
}
