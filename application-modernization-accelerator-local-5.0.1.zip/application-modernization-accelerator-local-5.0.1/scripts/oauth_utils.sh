#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2026
# ---------------------------------------------

# OAuth Utility Functions
# Common functions for OAuth configuration and validation
# Used by configure_oauth.sh

# Default timeout for HTTP requests (in seconds)
OAUTH_HTTP_TIMEOUT=${OAUTH_HTTP_TIMEOUT:-5}

# Function to fetch HTTP response with body
# Returns response body and HTTP code separated by newline
# Usage: fetch_http_response "https://example.com" "GET"
fetch_http_response() {
    local url=$1
    local method=${2:-GET}
    local timeout=${3:-$OAUTH_HTTP_TIMEOUT}
    
    # -k allows self-signed certificates (common in dev/test environments)
    timeout $((timeout + 1)) curl -k -s -w "\n%{http_code}" \
        -X "$method" \
        --connect-timeout "$timeout" \
        --max-time "$timeout" \
        --retry 3 \
        --retry-delay 1 \
        --retry-max-time $((timeout * 2)) \
        --no-keepalive \
        -L \
        "$url" 2>/dev/null
}

# Function to extract JSON value using grep/sed
# Usage: extract_json_value "$json_string" "key_name"
extract_json_value() {
    local json=$1
    local key=$2
    local value=$(echo "$json" | grep -o "\"$key\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" | head -n1 | sed "s/.*\"$key\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/")
    # Trim leading/trailing whitespace and newlines
    echo "$value" | tr -d '\n\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'
}

# Function to extract JSON array using grep/sed
# Usage: extract_json_array "$json_string" "array_key"
extract_json_array() {
    local json=$1
    local key=$2
    echo "$json" | grep -o "\"$key\"[[:space:]]*:[[:space:]]*\[[^]]*\]" | sed 's/.*\[\([^]]*\)\].*/\1/' | tr -d '"' | tr ',' ' '
}

# Function to fetch OIDC discovery document
# Tries standard discovery paths
# Usage: fetch_oidc_discovery "https://oauth-server.com"
# Returns: JSON discovery document or empty string on failure
fetch_oidc_discovery() {
    local base_endpoint=$1
    local timeout=${2:-$OAUTH_HTTP_TIMEOUT}
    local discovery_paths=(
        "/.well-known/openid-configuration"
        "/.well-known/oauth-authorization-server"
    )
    
    for path in "${discovery_paths[@]}"; do
        local full_url="${base_endpoint}${path}"
        local response
        local http_code
        
        response=$(fetch_http_response "$full_url" "GET" "$timeout")
        http_code=$(echo "$response" | tail -n1)
        local json=$(echo "$response" | sed '$d')
        
        if [[ "$http_code" == "200" ]] && [[ -n "$json" ]]; then
            echo "$json"
            return 0
        fi
    done
    
    return 1
}

# Function to append a config line safely
# Ensures the appended line starts on a new line even if the file lacks a trailing newline.
append_config_line_safely() {
    local config_file=$1
    local line=$2

    [[ -s "$config_file" ]] && [[ "$(tail -c 1 "$config_file" 2>/dev/null)" != "" ]] && printf '\n' >> "$config_file"
    printf '%s\n' "$line" >> "$config_file"
}

# Ensures the OAuth configuration section header exists in the config file
ensure_oauth_section_header() {
    local config_file=$1
    
    if ! grep -q "^## OAUTH CONFIGURATION" "$config_file" 2>/dev/null; then
        append_config_line_safely "$config_file" ""
        append_config_line_safely "$config_file" "## OAUTH CONFIGURATION"
    fi
}

# Export functions for use in other scripts
export -f fetch_http_response
export -f extract_json_value
export -f extract_json_array
export -f fetch_oidc_discovery
export -f append_config_line_safely
export -f ensure_oauth_section_header

# Made with Bob